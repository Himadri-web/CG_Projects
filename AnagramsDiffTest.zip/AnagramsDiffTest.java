/**
 * 
 */
package com.himadri.hacker.vijaylaxmi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

/**
 * @author Himadri
 *
 */
public class AnagramsDiffTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<Integer> listValue;
		String[] a = { "tea", "tea", "act" };
		String[] b = { "ate", "toe", "acts" };

//		String[] a = {"a", "jk", "abb", "mn", "abc", "AB"};
//		String[] b = {"bb", "kj", "bbc", "op", "def"};

		listValue = findAnagramDifference(a, b);

		System.out.println(listValue);

	}

	private static List<Integer> findAnagramDifference(String[] a, String[] b) {
		List<String> firstList = Arrays.asList(a);
		List<String> secondList = Arrays.asList(b);

		List<Integer> listValue = new ArrayList<>();

		int listSize = 0;
		listSize = firstList.size() > secondList.size() ? firstList.size() : secondList.size();

		for (int index = 0; index < listSize; index++) {
			if (index >= firstList.size() || index >= secondList.size()) {
				listValue.add(-1);
				continue;
			}

			int result = isAnagram(firstList.get(index), secondList.get(index));
			listValue.add(result);
		}

		return listValue;
	}
	
	private static int isAnagram(String strValue1, String strValue2) {

		boolean isAnagram = false;
		if (strValue1 != null && strValue1.isEmpty() && strValue2 != null && strValue2.isEmpty()) {
			System.out.println("Encounter error, Kindly pass both the value!!!");
			return -1;
		}

		if (strValue1.length() != strValue2.length()) {
			return -1;
		}

		strValue1 = strValue1.replaceAll("\\s", "").toUpperCase();
		strValue2 = strValue2.replaceAll("\\s", "").toUpperCase();

//		System.out.println(strValue1 +" : "+ strValue2);
		char[] charValues1 = strValue1.toCharArray();
		char[] charValue2 = strValue2.toCharArray();
		Arrays.sort(charValues1);
		Arrays.sort(charValue2);
		Map<Character, Integer> mapSecondStr = new Hashtable<>();

		// Store 2nd string characters into a map
		for (char value : charValue2) {
			if (mapSecondStr.containsKey(value)) {
				mapSecondStr.put(value, mapSecondStr.get(value) + 1);
			} else {
				mapSecondStr.put(value, 1);
			}
		}

		int countDiff = 0;
		for (int index = 0; index < charValues1.length; index++) {
			if (charValues1[index] != charValue2[index]) {
				isAnagram = false;
				char value1 = charValues1[index];
				if (!mapSecondStr.containsKey(value1)) {
					countDiff++;
				}
			}
		}

		if (isAnagram) {
			return 0;
		}

		return countDiff;
	}
}
