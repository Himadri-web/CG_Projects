package com.himadri.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.himadri.demo.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {

}
