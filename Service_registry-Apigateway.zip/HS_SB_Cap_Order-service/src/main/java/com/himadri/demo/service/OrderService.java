package com.himadri.demo.service;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.himadri.demo.entity.Order;
import com.himadri.demo.repository.OrderRepository;
import com.himadri.demo.util.Payment;
import com.himadri.demo.util.TransactionRequest;
import com.himadri.demo.util.TransactionResponse;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public TransactionResponse saveOrder(TransactionRequest request) {
		String responseMgs="";
		Order order =request.getOrder();
		Payment payment = request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		
		//do a rest call to payment API //localhost:8090
		Payment paymentResponse = restTemplate.postForObject("http://mypayment-service/payment/doPayment", payment, Payment.class);
		responseMgs = paymentResponse.getPaymentStatus().equals("success") ? "Payment processed successfully and order placed!" : "Payment process failed in payment api";
		
		orderRepository.save(order);
		
		return new TransactionResponse(order, paymentResponse.getAmount(), paymentResponse.getTransactionId(), responseMgs);
	}

}
