package com.himadri.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.himadri.demo.entity.Order;
import com.himadri.demo.service.OrderService;
import com.himadri.demo.util.Payment;
import com.himadri.demo.util.TransactionRequest;
import com.himadri.demo.util.TransactionResponse;

@RestController
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private OrderService orderService;
	
	@PostMapping("/bookOrder")
	public TransactionResponse bookOrder(@RequestBody TransactionRequest request) {
		
		return orderService.saveOrder(request);
		
		
	}

}
