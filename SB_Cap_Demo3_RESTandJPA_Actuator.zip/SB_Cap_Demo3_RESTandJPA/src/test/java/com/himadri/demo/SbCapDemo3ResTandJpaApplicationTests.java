package com.himadri.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbCapDemo3ResTandJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
