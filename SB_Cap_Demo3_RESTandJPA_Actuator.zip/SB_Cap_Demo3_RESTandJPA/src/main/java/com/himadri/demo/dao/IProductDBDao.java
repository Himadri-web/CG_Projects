package com.himadri.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.himadri.demo.model.Product;

@Repository("productDBDao")
public interface IProductDBDao extends JpaRepository<Product, String> {

}
