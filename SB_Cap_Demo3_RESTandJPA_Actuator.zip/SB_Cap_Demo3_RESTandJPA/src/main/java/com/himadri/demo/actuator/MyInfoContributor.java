package com.himadri.demo.actuator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.actuate.info.Info.Builder;
import org.springframework.boot.actuate.info.InfoContributor;
import org.springframework.stereotype.Component;

@Component
public class MyInfoContributor implements InfoContributor {

	@Override
	public void contribute(Builder builder) {
		Map<String, String> appDetails = new HashMap<>();
		appDetails.put("name", "My Spring Boot Application customized info");
		appDetails.put("type", "Spring Boot");
		appDetails.put("typeCustom", "Spring Boot!!!");
		
		builder.withDetail("app1", appDetails);
		
		
		Map<String, Integer> userDetails = new HashMap<>();
        userDetails.put("active", 1);
        userDetails.put("inactive", 2);
        builder.withDetail("users", userDetails);
	}
}
