package com.himadri.demo.dao;

import java.util.List;

import com.himadri.demo.model.Product;

public interface IProductDAO {

	public List<Product> getAllProducts();

	public List<Product> createProduct(Product product);

	public Product findProduct(String productID);

	public Boolean deleteProduct(String productId);

	public Product updateProduct(String productId, Product productToUpdate);
	



}
