package com.himadri.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.himadri.demo.model.Product;

@Repository
public class ProductDAOImplDummy implements IProductDAO {

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		System.out.println("Inside Dummy");
		return null;
	}

	@Override
	public List<Product> createProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product findProduct(String productID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateProduct(String productId, Product productToUpdate) {
		// TODO Auto-generated method stub
		return null;
	}

}
