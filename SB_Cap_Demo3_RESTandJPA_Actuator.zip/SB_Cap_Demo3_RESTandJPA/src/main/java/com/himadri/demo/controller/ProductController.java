package com.himadri.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.himadri.demo.dao.IProductDAO;
import com.himadri.demo.model.Product;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@RequestMapping("/api/v1")
@EnableSwagger2
public class ProductController {
	
	@Autowired
	private IProductDAO productDao; 
		
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		System.out.println("Inside all Products");
		
		List<Product> products = productDao.getAllProducts();
		
		if(products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry! No Products available!",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);		
	}
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(@RequestBody Product product){
		List<Product> products = productDao.createProduct(product);
		if(products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry! Failed to create product", HttpStatus.BAD_REQUEST);
			
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.CREATED);
		
	}
	
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> getProductByID(@PathVariable("productId") String productId ) {
		Product product = productDao.findProduct(productId);
		if(product == null) {
			return new ResponseEntity("Sorry! Product ID not found!",HttpStatus.NOT_FOUND);
			
		}
		
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}
	
	@DeleteMapping("/products/{productId}")
	public ResponseEntity<Boolean> deleteProduct(@PathVariable("productId") String productId){
		Boolean isProddeleted = productDao.deleteProduct(productId);
		if(!isProddeleted) {
			return new ResponseEntity("Sorry! Product not Deleted",HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<Boolean>(isProddeleted,HttpStatus.OK);
		
	}
	
	@PutMapping("/products/{productId}")
	public ResponseEntity<Product> updateProduct(@PathVariable("productId") String productId, @RequestBody Product productToUpdate){
		Product product = productDao.updateProduct(productId, productToUpdate);
		if(product == null) {
			return new ResponseEntity("Sorry! Product not Updated",HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
		
	}
	
	
	

}
