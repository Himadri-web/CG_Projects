package com.himadri.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.himadri.demo.dao.IProductDBDao;
import com.himadri.demo.model.Product;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@RestController
@RequestMapping("/api/v2")
@EnableSwagger2
//@RequestMapping
public class ProductDBController {
	@Autowired
	private IProductDBDao productDBDao;
	
	@PostMapping("/products")
	public ResponseEntity<List<Product>> createProduct(@RequestBody Product product){
		productDBDao.save(product);
		
		List<Product> products = new ArrayList<>();
		products.add(product);
		if(products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry! Product failed to create", HttpStatus.NOT_ACCEPTABLE);
		}
		return new ResponseEntity<List<Product>>(products,HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts(){
		
		List<Product> products = productDBDao.findAll();
		if(products == null || products.isEmpty()) {
			return new ResponseEntity("Sorry!, Product not available", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);		
	}
	
	@GetMapping("products/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable("productId") String productId) {
		
		
		Product product = productDBDao.getOne(productId);
		if(product == null) {
			return new ResponseEntity("Sorry!, Product not available with this Id", HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product, HttpStatus.OK);
		
	}
	
	@DeleteMapping("products/{productId}")
	public ResponseEntity<List<Product>> deleteProduct(@PathVariable("productId") String productId){
		productDBDao.deleteById(productId);
		//Need to implement to check whether the product is exist after delete if not then return the available rest of the product
		return getAllProducts();
				
	}
	
	public void updateProduct(@PathVariable("productId") String productId,@RequestBody Product product) {
//		productDBDao.
	}
	
	
	@GetMapping("/greet")
	public String sayGreet() {
		return "Hello World!";
	}
	

}
