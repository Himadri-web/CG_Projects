package com.himadri.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.himadri.demo.model.Product;

@Repository("productDao")
public class ProductDAOImpl implements IProductDAO {
	
	private static List<Product> productList = dummyDB();

	@Override
	public List<Product> getAllProducts() {
		return productList;
	}
	
	@Override
	public List<Product> createProduct(Product product) {
		productList.add(product);
		return productList;
	}
	
	

	private static List<Product> dummyDB() {
		List<Product> products = new ArrayList<>();
		products.add(new Product("101", "Mobile", 12000, 10, new Date()));
		products.add(new Product("102", "IPad", 15000, 20, new Date()));
		products.add(new Product("103", "TV", 45000, 15, new Date()));
		products.add(new Product("104", "Mouse", 400, 50, new Date()));
		return products;
	}

	@Override
	public Product findProduct(String productID) {
		
		for(Product product : productList) {
			if(product.getProductID().equals(productID)) {
				return product;
				
			}
		}
		
		return null;
	}

	@Override
	public Boolean deleteProduct(String productId) {
		for(Product product : productList) {
			if(product.getProductID().equals(productId)) {
				productList.remove(product);
				return true;
			}
		}
		return false;
	}

	@Override
	public Product updateProduct(String productId, Product productToUpdate) {
		Product product = findProduct(productId);
		product.setPrice(productToUpdate.getPrice());
		product.setQuantity(productToUpdate.getQuantity());
//		product.setProductName(productName);(productToUpdate.getPrice());		
		
		return product;
	}



	

}
