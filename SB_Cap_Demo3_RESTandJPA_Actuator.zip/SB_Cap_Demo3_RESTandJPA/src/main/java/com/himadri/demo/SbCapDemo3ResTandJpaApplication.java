package com.himadri.demo;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@SpringBootApplication
public class SbCapDemo3ResTandJpaApplication {

	public static void main(String[] args) {
		System.out.println("Before Run!");
		SpringApplication.run(SbCapDemo3ResTandJpaApplication.class, args);
		System.out.println("After Run!");
	}
	
	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).select()
				.apis(RequestHandlerSelectors.basePackage("com.himadri.demo")).paths(regex("/api.*")).build();
	}
	

}
