package com.himadri.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonAppend;
//@JsonIgnoreProperties({"hibernatelazyInitializer"})
@JsonIgnoreProperties({"hibernateLazyInitializer"})
@Entity
public class Product {
	@Id
	private String productID;
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}
	private String productName;
	private float price;
	private int quantity;
	private Date expireDate;
	
	public Product() {
		super();
	}
	
	
	public Product(String productID, String productName, float price, int quantity, Date expireDate) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.price = price;
		this.quantity = quantity;
		this.expireDate = expireDate;
	}
	public String getProductID() {
		return productID;
	}
	public String getProductName() {
		return productName;
	}
	public float getPrice() {
		return price;
	}
	public int getQuantity() {
		return quantity;
	}
	public Date getExpireDate() {
		return expireDate;
	}

}
