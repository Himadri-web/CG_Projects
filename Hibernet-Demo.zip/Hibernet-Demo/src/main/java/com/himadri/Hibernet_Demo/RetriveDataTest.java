package com.himadri.Hibernet_Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class RetriveDataTest {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure().addAnnotatedClass(AlienEmbeddable.class);
		ServiceRegistry sr = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(sr);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		AlienEmbeddable alien = new AlienEmbeddable();
		alien.setAid(102);
		alien = (AlienEmbeddable) session.get(AlienEmbeddable.class, alien.getAid());
		tx.commit();
		System.out.println(alien);
		
	}

}
