/**
 * 
 */
package com.himadri.Hibernet_Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * @author Himadri
 *
 */
public class FirstLevelCacheTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Alien.class);
		ServiceRegistry sr = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(sr);
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		Alien alien = null;
		//first level cache
		alien = (Alien) session.get(Alien.class, 101);
		System.out.println(alien);
		
		alien = (Alien) session.get(Alien.class, 101);
		System.out.println(alien);
		
		tx.commit();
		
	}

}
