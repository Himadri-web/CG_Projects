package com.himadri.Hibernet_Demo;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Alien alien1 = new Alien();
        alien1.setAid(101);
        alien1.setAname("Himadri");
        alien1.setColor("Black");
        
        Alien alien2 = new Alien();
        alien2.setAid(102);
        alien2.setAname("Himadri1");
        alien2.setColor("Black1");
        
        //Configuration configuration = new Configuration().configure().addAnnotatedClass(Alien.class);
        //SessionFactory sessionFactory = configuration.buildSessionFactory();
        
        Configuration configuration = new Configuration().configure().addAnnotatedClass(Alien.class);
        
        ServiceRegistry sr = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
        SessionFactory sessionFactory = configuration.buildSessionFactory(sr);
//        
        Session session = sessionFactory.openSession();
        
        Transaction tx = session.beginTransaction();
        session.saveOrUpdate(alien1);
        session.saveOrUpdate(alien2);
        tx.commit();
    }
}
