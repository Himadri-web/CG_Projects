package com.himadri.Hibernet_Demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.himadri.Hibernet_Demo.embtest.AlienName;

//@Entity(name="Tab_Alien")
@Entity
@Table(name="Tab_Alien")
public class AlienEmbeddable {//POJO
	@Id
	private int aid;
	private AlienName aname;
	
	//@Transient
	private String color;
	
	public AlienName getAname() {
		return aname;
	}
	public void setAname(AlienName aname) {
		this.aname = aname;
	}
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	/*public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}*/
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	@Override
	public String toString() {
		return "Alien [aid=" + aid + ", aname=" + aname + ", color=" + color + "]";
	}
	
	

}
