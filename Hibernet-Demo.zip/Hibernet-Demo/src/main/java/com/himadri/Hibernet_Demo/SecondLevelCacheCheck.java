/**
 * 
 */
package com.himadri.Hibernet_Demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * @author Himadri
 *
 */
public class SecondLevelCacheCheck {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Alien alien = null;
		Configuration configuration = new Configuration().configure().addAnnotatedClass(Alien.class);
		ServiceRegistry sr = new ServiceRegistryBuilder().applySettings(configuration.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = configuration.buildSessionFactory(sr);
		
		//first session
		Session session1 = sessionFactory.openSession();
		session1.beginTransaction();
		
		alien = (Alien) session1.get(Alien.class, 101);
		System.out.println(alien);
		
		session1.getTransaction().commit();
		session1.close();
		
		//2nd session
		Session session2 = sessionFactory.openSession();
		Transaction tx = session2.beginTransaction();
		
		alien = (Alien) session2.get(Alien.class, 101);
		System.out.println(alien);
		
		session2.getTransaction().commit();
		session2.close();
	}

}
